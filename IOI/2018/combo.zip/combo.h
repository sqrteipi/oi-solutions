#include <string>

std::string guess_sequence(int N);

int press(std::string p);
