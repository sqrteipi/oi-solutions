g++ grader.cpp citymapping.cpp -o citymapping -Wall -static -O2 -lm -m64 -s -w -std=gnu++14 -fmax-errors=512
