#include <bits/stdc++.h>
using namespace std;

std::vector<std::vector<int>> colouring(int N, int M);

static int N, M;
static std::vector<std::vector<int>> reported;

double get_score(int C){
    if (C <= 16) return 100;
    else if (C <= 32) return 55 + 2.0 * (32 - C);
    else if (C <= 256) return 15 + 40.0 * 32 / C;
    else if (C <= 66049) return 5 + 15.0 * 256 / C;
    else return 0;
}

int main() {
    cin >> N >> M;

    reported = colouring(N, M);

    if (reported.size() != N) {
        printf("Incorrect. The size of the colouring is not N x M.\n");
        return 0;
    }
    for (int i = 0; i < N; i++) {
        if (reported[i].size() != M) {
            printf("Incorrect. The size of the colouring is not N x M.\n");
            return 0;
        }
    }
    
    vector a = reported;
    
    set<vector<int>> S;
    for (int i = 0; i < N - 1; i++) {
        for (int j = 0; j < M - 1; j++) {
            vector<int> v;
            for (int x = 0; x < 2; x++) {
                for (int y = 0; y < 2; y++) {
                    v.push_back(a[i + x][j + y]);
                }
            }
            S.insert(v);
        }
    }

    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            cout << a[i][j] << " \n"[j == M - 1];
        }
    }

    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            if (a[i][j] < 0 || a[i][j] > 1'000'000'000) {
                printf("Incorrect. Colour at block (%d, %d) out of bound\n", i, j);
                return 0;
            }
        }
    }

    set<int> colours;
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            colours.insert(a[i][j]);
        }
    }
    int C = colours.size();

    if (S.size() != (N - 1) * (M - 1)) {
        printf("Incorrect. Colours of some 2x2 blocks are repeated\n");
        return 0;
    }

    printf("Correct. Used %d colours, score = %.3lf\n", C, get_score(C));
    return 0;
}
