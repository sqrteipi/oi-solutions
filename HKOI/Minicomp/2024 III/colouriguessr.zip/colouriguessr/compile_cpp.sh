g++ -static -std=c++20 -Wno-unused-result -s -O2 -Ilib -o colouriguessr colouriguessr.cpp sample_grader.cpp
